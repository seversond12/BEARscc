library(testthat)
library(BEARscc)

test_check("BEARscc")
