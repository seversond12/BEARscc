## ----setup, include = FALSE----------------------------------------------
knitr::opts_chunk$set(
    collapse = TRUE,
    comment = "#>"
)

## ----include=TRUE--------------------------------------------------------
install.packages('../inst/BEARscc_0.99.0.tar.gz', repos = NULL, type="source")

