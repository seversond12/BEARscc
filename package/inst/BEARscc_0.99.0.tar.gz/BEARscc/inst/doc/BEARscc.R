## ----setup, include = FALSE----------------------------------------------
knitr::opts_chunk$set(
    collapse = TRUE,
    comment = "#>"
)

## ----include=TRUE--------------------------------------------------------
install.packages('../inst/BEARscc_0.99.0.tar.gz', repos = NULL, type="source")
library("BEARscc")

## ---- eval=TRUE----------------------------------------------------------
library('data.table')
data("BEARscc_examples")

## ---- eval=TRUE----------------------------------------------------------
head(ERCC.counts.df[,1:2])

head(data.counts.df[,1:2]) 

head(ERCC.meta.df)

## ---- eval=TRUE----------------------------------------------------------
results <- estimate_noiseparameters(ERCC.counts.df,
                                    data.counts.df,
                                    ERCC.meta.df,
                                    granularity=30,
                                    write.noise.model=TRUE,
                                    file="noise_estimation",
                                    model_view=c("Observed","Optimized"))

