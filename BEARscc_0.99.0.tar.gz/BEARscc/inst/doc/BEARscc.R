## ----setup, include = FALSE----------------------------------------------
knitr::opts_chunk$set(
    collapse = TRUE,
    comment = "#>"
)

## ----install_BEARscc, include=TRUE---------------------------------------
install.packages('../inst/BEARscc_0.99.0.tar.gz', repos = NULL, type="source")
library("BEARscc")

## ----load_data, eval=TRUE------------------------------------------------
library('data.table')
data("BEARscc_examples")

## ----display_data, eval=TRUE---------------------------------------------
head(ERCC.counts.df[,1:2])

head(data.counts.df[,1:2]) 

head(ERCC.meta.df)

## ----estimate_noise, eval=TRUE-------------------------------------------
results <- estimate_noiseparameters(ERCC.counts.df,
                                    data.counts.df,
                                    ERCC.meta.df,
                                    granularity=30,
                                    write.noise.model=FALSE,
                                    model_view=c("Observed","Optimized"))

## ----simulate_replicates, eval=TRUE--------------------------------------
    sim_replicates <- create_noiseinjected_counts(results, n=3)

## ----estimate_noise_HPC, eval=FALSE, include=TRUE------------------------
#  results <- estimate_noiseparameters(ERCC.counts.df,
#                                      data.counts.df,
#                                      ERCC.meta.df,
#                                      granularity=30,
#                                      write.noise.model=TRUE,
#                                      file="tutorial_example",
#                                      model_view=c("Observed","Optimized"))

## ----write_data, eval=FALSE, include=TRUE--------------------------------
#  counts.dt<-data.table(rbind(ERCC.counts.df, data.counts.df),
#      keep.rownames = TRUE)
#  write.table(counts.dt, file="counts_example.tsv")

## ----HPC_example, eval=FALSE, include=TRUE-------------------------------
#  library("data.table")
#  library("BEARscc")
#  library("parallel")
#  
#  #### Load data ####
#  ITERATION<-commandArgs(trailingOnly=TRUE)[1]
#  no_cores<-4
#  counts.dt<-fread("counts_example.tsv")
#  #filter out zero counts to speed up algorithm
#  counts.dt<-counts.dt[rowSums(counts.dt[,.SD>0,.SD=c(2:dim(counts.dt)[2])])>0,]
#  probs4detection<-fread("tutorial_example_bayesianestimates.xls")
#  parameters<-fread("tutorial_example_parameters4randomize.xls")
#  
#  #### Simulate replicates ####
#  cl <- makeCluster(no_cores, FORK=TRUE)
#  counts.error<-prepare_probabilities(counts.dt,
#      probs4detection=probs4detection, parameters=parameters,
#      HPC_genewise_permute_count=HPC_genewise_permute_count,
#      HPC_permute_count=HPC_permute_count, HPC_randomizer=HPC_randomizer,
#      total_sampling=2500)
#  counts.error.df<-data.frame(t(counts.error), row.names=counts.dt$GENE_ID)
#  counts.error.dt<-data.table(counts.error.df, keep.rownames=TRUE)
#  colnames(counts.error.dt)<-colnames(counts.dt)
#  write.table(counts.error.dt, file=paste("simulated_replicates/",
#      paste(ITERATION,"sim_replicate_counts.txt",sep="_"),
#      sep=""), quote =FALSE, row.names=FALSE)
#  stopCluster(cl)

