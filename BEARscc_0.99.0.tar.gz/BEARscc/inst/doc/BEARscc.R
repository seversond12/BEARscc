## ----setup, include = FALSE----------------------------------------------
knitr::opts_chunk$set(
    collapse = TRUE,
    comment = "#>"
)

## ----install_BEARscc, include=TRUE---------------------------------------
install.packages('../inst/BEARscc_0.99.0.tar.gz', repos = NULL, type="source")
library("BEARscc")

## ----install, eval=FALSE, include=TRUE-----------------------------------
#  install.packages('data.table')
#  install.packages('ggplot2')
#  install.packages('cowplot')

## ----load_data, eval=TRUE------------------------------------------------
library('data.table')
data("BEARscc_examples")

## ----display_data, eval=TRUE---------------------------------------------
head(ERCC.counts.df[,1:2])

head(data.counts.df[,1:2]) 

head(ERCC.meta.df)

## ----estimate_noise, eval=TRUE-------------------------------------------
results <- estimate_noiseparameters(ERCC.counts.df,
                                    data.counts.df,
                                    ERCC.meta.df,
                                    granularity=30,
                                    alpha_granularity = 0.05,
                                    write.noise.model=FALSE,
                                    model_view=c("Observed","Optimized"))

## ----simulate_replicates, eval=TRUE--------------------------------------
    sim_replicates <- create_noiseinjected_counts(results, n=10)

## ----estimate_noise_HPC, eval=FALSE, include=TRUE------------------------
#  results <- estimate_noiseparameters(ERCC.counts.df,
#                                      data.counts.df,
#                                      ERCC.meta.df,
#                                      granularity=30,
#                                      write.noise.model=TRUE,
#                                      file="tutorial_example",
#                                      model_view=c("Observed","Optimized"))

## ----write_data, eval=FALSE, include=TRUE--------------------------------
#  counts.dt<-data.table(rbind(ERCC.counts.df, data.counts.df),
#      keep.rownames = TRUE)
#  write.table(counts.dt, file="counts_example.tsv")

## ----HPC_example, eval=FALSE, include=TRUE-------------------------------
#  library("data.table")
#  library("BEARscc")
#  library("parallel")
#  
#  #### Load data ####
#  ITERATION<-commandArgs(trailingOnly=TRUE)[1]
#  no_cores<-4
#  counts.dt<-fread("counts_example.tsv")
#  #filter out zero counts to speed up algorithm
#  counts.dt<-counts.dt[rowSums(counts.dt[,.SD>0,.SD=c(2:dim(counts.dt)[2])])>0,]
#  probs4detection<-fread("tutorial_example_bayesianestimates.xls")
#  parameters<-fread("tutorial_example_parameters4randomize.xls")
#  
#  #### Simulate replicates ####
#  cl <- makeCluster(no_cores, FORK=TRUE)
#  counts.error<-prepare_probabilities(counts.dt,
#      probs4detection=probs4detection, parameters=parameters,
#      HPC_genewise_permute_count=HPC_genewise_permute_count,
#      HPC_permute_count=HPC_permute_count, HPC_randomizer=HPC_randomizer,
#      total_sampling=2500)
#  counts.error.df<-data.frame(t(counts.error), row.names=counts.dt$GENE_ID)
#  counts.error.dt<-data.table(counts.error.df, keep.rownames=TRUE)
#  colnames(counts.error.dt)<-colnames(counts.dt)
#  write.table(counts.error.dt, file=paste("simulated_replicates/",
#      paste(ITERATION,"sim_replicate_counts.txt",sep="_"),
#      sep=""), quote =FALSE, row.names=FALSE)
#  stopCluster(cl)

## ----recluster, include=TRUE, eval=TRUE----------------------------------
recluster <- function(x) {
    x <- data.frame(x, row.names = "GENE_ID")
    scramble <- sample(colnames(x), size=length(colnames(x)), replace=FALSE)
    x <- x[,scramble]
    clust <- hclust(dist(t(x),method="euclidean"),method="complete")
    clust <- cutree(clust,2)
    data.frame(clust)
}

## ----recluster_go, include=TRUE, evalue=TRUE-----------------------------
cluster.list<-lapply(sim_replicates, `recluster`)
clusters.df<-do.call("cbind", cluster.list)
colnames(clusters.df)<-names(cluster.list)

## ----compute_consensus, eval=TRUE, include=TRUE--------------------------
noise_consensus <- compute_consensus(clusters.df)
head(noise_consensus[,1:3], n=3)

## ----plot_noise_consensus, eval=TRUE, include=TRUE-----------------------
library("NMF")
aheatmap(noise_consensus, breaks=0.5)

## ----cluster_consensus, include=TRUE, eval=TRUE--------------------------
vector <- seq(from=2, to=5, by=1)
BEARscc_clusts.df <- cluster_consensus(noise_consensus,vector)

## ----add_original, include=TRUE, eval=TRUE-------------------------------
BEARscc_clusts.df <- cbind(BEARscc_clusts.df, 
    Original=clusters.df$Original_counts)

## ----compute_cluster_scores, include=TRUE, eval=TRUE---------------------
cluster_scores.dt <- report_cluster_metrics(BEARscc_clusts.df, 
    noise_consensus, plot=FALSE)
head(cluster_scores.dt, n=5)

## ----plot_clusterscores_original, include=TRUE, eval=TRUE----------------
library("ggplot2")
library("cowplot")
ggplot(cluster_scores.dt[Clustering=="Original"][Metric=="score"], 
    aes(x=`Cluster identity`, y=Value) )+
    geom_bar(aes(fill=`Cluster identity`), stat="identity")+
    xlab("Cluster identity")+ylab("Cluster score")+
    ggtitle("Original cluster scores")+guides(fill=FALSE)

## ----plot_clusterstability_original, include=TRUE, eval=TRUE-------------
ggplot(cluster_scores.dt[Clustering=="Original"][Metric=="Stability"], 
    aes(x=`Cluster identity`, y=Value) )+
    geom_bar(aes(fill=`Cluster identity`), stat="identity")+
    xlab("Cluster identity")+ylab("Cluster stability")+
    ggtitle("Original cluster stability")+guides(fill=FALSE)

## ----plot_clusterpromiscuity_original, include=TRUE, eval=TRUE-----------
ggplot(cluster_scores.dt[Clustering=="Original"][Metric=="Promiscuity"], 
    aes(x=`Cluster identity`, y=Value) )+
    geom_bar(aes(fill=`Cluster identity`), stat="identity")+
    xlab("Cluster identity")+ylab("Cluster promiscuity")+
    ggtitle("Original cluster promiscuity")+guides(fill=FALSE)

## ----compute_cell_scores, include=TRUE, eval=TRUE------------------------
cell_scores.dt <- report_cell_metrics(BEARscc_clusts.df, noise_consensus)
head(cell_scores.dt, n=4)

## ----plot_cellscore_original, include=TRUE, eval=TRUE--------------------
ggplot(cell_scores.dt[Clustering=="Original"][Metric=="score"], 
    aes(x=factor(`Cluster identity`), y=Value) )+
    geom_jitter(aes(color=factor(`Cluster identity`)), stat="identity")+
    xlab("Cluster identity")+ylab("Cell scores")+
    ggtitle("Original clustering cell scores")+guides(color=FALSE)

## ----choosing_k, include=TRUE, eval=TRUE---------------------------------
ggplot(cluster_scores.dt[Metric=="score"], 
    aes(x=`Clustering`, y=Value) )+
    geom_boxplot(aes(fill=`Clustering`))+
    xlab("Clustering")+ylab("Cluster score distribution")+
    ggtitle("Original cluster scores for each clustering")+
    guides(fill=FALSE)

